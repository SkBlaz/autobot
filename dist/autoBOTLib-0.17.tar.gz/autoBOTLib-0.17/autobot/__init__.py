from data_utils import *
from sklearn import preprocessing
from feature_constructors import *
from strategy_ga import *

# pipeline_obj = GAlearner(train_sequences,
#                          train_targets,
#                          time_constraint=time_constraint,
#                          num_cpu=8,
#                          task_name=task_name,
#                          hof_size=hof_size,
#                          representation_type=args.representation_type)

# pipeline_obj.evolve(nind=popsize,
#                     strategy="evolution",
#                     crossover_proba=crossover_rate,
#                     mutpb=mutation_rate)
